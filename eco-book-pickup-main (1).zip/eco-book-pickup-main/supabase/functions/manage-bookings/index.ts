import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const url = new URL(req.url);
    const bookingId = url.searchParams.get('id');

    // GET - List all bookings with city details
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          cities (
            name,
            rate_per_kg
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      console.log(`Retrieved ${data?.length || 0} bookings`);
      
      return new Response(
        JSON.stringify({ bookings: data }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    // PATCH - Update booking status
    if (req.method === 'PATCH') {
      if (!bookingId) {
        return new Response(
          JSON.stringify({ error: 'Booking ID is required' }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 400 
          }
        );
      }

      const { status } = await req.json();

      if (!status || !['pending', 'confirmed', 'completed', 'cancelled'].includes(status)) {
        return new Response(
          JSON.stringify({ error: 'Valid status is required (pending, confirmed, completed, cancelled)' }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 400 
          }
        );
      }

      const { data, error } = await supabase
        .from('bookings')
        .update({ status })
        .eq('id', bookingId)
        .select()
        .single();

      if (error) throw error;

      console.log(`Updated booking ${bookingId} to status: ${status}`);

      return new Response(
        JSON.stringify({ booking: data }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 405 
      }
    );

  } catch (error) {
    console.error('Error in manage-bookings function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'An error occurred' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
