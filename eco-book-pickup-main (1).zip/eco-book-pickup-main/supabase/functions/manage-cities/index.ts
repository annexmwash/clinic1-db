import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const url = new URL(req.url);
    const cityId = url.searchParams.get('id');

    // GET - List all cities
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('cities')
        .select('*')
        .order('name');

      if (error) throw error;

      console.log(`Retrieved ${data?.length || 0} cities`);

      return new Response(
        JSON.stringify({ cities: data }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    // POST - Create new city
    if (req.method === 'POST') {
      const { name, rate_per_kg, is_active } = await req.json();

      if (!name || !rate_per_kg) {
        return new Response(
          JSON.stringify({ error: 'Name and rate_per_kg are required' }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 400 
          }
        );
      }

      const { data, error } = await supabase
        .from('cities')
        .insert([{ 
          name, 
          rate_per_kg: parseFloat(rate_per_kg),
          is_active: is_active ?? true 
        }])
        .select()
        .single();

      if (error) throw error;

      console.log(`Created city: ${name}`);

      return new Response(
        JSON.stringify({ city: data }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 201 
        }
      );
    }

    // PATCH - Update city
    if (req.method === 'PATCH') {
      if (!cityId) {
        return new Response(
          JSON.stringify({ error: 'City ID is required' }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 400 
          }
        );
      }

      const updates = await req.json();
      const allowedFields = ['name', 'rate_per_kg', 'is_active'];
      const filteredUpdates: any = {};

      for (const field of allowedFields) {
        if (updates[field] !== undefined) {
          filteredUpdates[field] = field === 'rate_per_kg' 
            ? parseFloat(updates[field]) 
            : updates[field];
        }
      }

      if (Object.keys(filteredUpdates).length === 0) {
        return new Response(
          JSON.stringify({ error: 'No valid fields to update' }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 400 
          }
        );
      }

      const { data, error } = await supabase
        .from('cities')
        .update(filteredUpdates)
        .eq('id', cityId)
        .select()
        .single();

      if (error) throw error;

      console.log(`Updated city ${cityId}:`, filteredUpdates);

      return new Response(
        JSON.stringify({ city: data }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 405 
      }
    );

  } catch (error) {
    console.error('Error in manage-cities function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'An error occurred' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
