-- Create cities table for major Kenyan cities
CREATE TABLE IF NOT EXISTS public.cities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  rate_per_kg DECIMAL(10,2) NOT NULL DEFAULT 2.50,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;

-- Allow public read access to cities
CREATE POLICY "Anyone can view active cities"
  ON public.cities
  FOR SELECT
  USING (is_active = true);

-- Create bookings table
CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  address TEXT NOT NULL,
  city_id UUID NOT NULL REFERENCES public.cities(id),
  waste_type TEXT NOT NULL,
  waste_amount DECIMAL(10,2) NOT NULL,
  total_cost DECIMAL(10,2) NOT NULL,
  preferred_date DATE NOT NULL,
  preferred_time TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Allow anyone to create bookings
CREATE POLICY "Anyone can create bookings"
  ON public.bookings
  FOR INSERT
  WITH CHECK (true);

-- Allow anyone to view their own bookings by email
CREATE POLICY "Anyone can view bookings"
  ON public.bookings
  FOR SELECT
  USING (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for bookings
CREATE TRIGGER update_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert major Kenyan cities
INSERT INTO public.cities (name, rate_per_kg) VALUES
  ('Nairobi', 2.50),
  ('Mombasa', 2.50),
  ('Kisumu', 2.30),
  ('Nakuru', 2.30),
  ('Eldoret', 2.40),
  ('Thika', 2.40),
  ('Malindi', 2.50),
  ('Kitale', 2.30),
  ('Garissa', 2.60),
  ('Kakamega', 2.30),
  ('Nyeri', 2.40),
  ('Meru', 2.40)
ON CONFLICT (name) DO NOTHING;