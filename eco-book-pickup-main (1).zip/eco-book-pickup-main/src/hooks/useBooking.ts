import { useMutation } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface BookingInput {
  customer_name: string;
  phone: string;
  email: string;
  address: string;
  city_id: string;
  waste_type: string;
  waste_amount: number;
  total_cost: number;
  preferred_date: string;
  preferred_time: string;
  payment_method: string;
}

export const useCreateBooking = () => {
  return useMutation({
    mutationFn: async (booking: BookingInput) => {
      const { data, error } = await supabase
        .from('bookings')
        .insert([booking])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onError: (error) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking. Please try again.",
        variant: "destructive"
      });
    }
  });
};
