import React, { useState } from 'react';
import HeroSection from '@/components/HeroSection';
import BookingForm, { BookingData } from '@/components/BookingForm';
import HowItWorks from '@/components/HowItWorks';
import ConfirmationPage from '@/components/ConfirmationPage';
import { toast } from '@/hooks/use-toast';
import { ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCreateBooking } from '@/hooks/useBooking';
import { format } from 'date-fns';

type ViewState = 'home' | 'booking' | 'confirmation';

const Index = () => {
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [bookingData, setBookingData] = useState<BookingData | null>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const createBooking = useCreateBooking();

  // Handle scroll to show/hide scroll-to-top button
  React.useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBooking = () => {
    const bookingSection = document.getElementById('booking-section');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleBookNow = () => {
    if (currentView === 'home') {
      setCurrentView('booking');
      // Small delay to ensure the component is rendered before scrolling
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 100);
    } else {
      scrollToBooking();
    }
  };

  const handleBookingSubmit = (data: BookingData) => {
    if (!data.date) {
      toast({
        title: "Missing Information",
        description: "Please select a collection date.",
        variant: "destructive"
      });
      return;
    }

    setBookingData(data);
    setCurrentView('confirmation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEdit = () => {
    setCurrentView('booking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleConfirm = async () => {
    if (!bookingData || !bookingData.date) return;

    const bookingInput = {
      customer_name: bookingData.fullName,
      phone: bookingData.phone,
      email: bookingData.email,
      address: bookingData.address,
      city_id: bookingData.cityId,
      waste_type: bookingData.wasteType,
      waste_amount: parseFloat(bookingData.amount),
      total_cost: parseFloat(bookingData.amount) * bookingData.ratePerKg,
      preferred_date: format(bookingData.date, 'yyyy-MM-dd'),
      preferred_time: bookingData.timeSlot,
      payment_method: bookingData.paymentMethod,
    };

    createBooking.mutate(bookingInput, {
      onSuccess: () => {
        toast({
          title: "Booking Confirmed!",
          description: "Your waste collection has been scheduled. You'll receive a confirmation SMS shortly.",
        });
        
        setTimeout(() => {
          setCurrentView('home');
          setBookingData(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }, 2000);
      }
    });
  };

  // Render different views
  if (currentView === 'confirmation' && bookingData) {
    return (
      <ConfirmationPage 
        bookingData={bookingData}
        onEdit={handleEdit}
        onConfirm={handleConfirm}
      />
    );
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      {currentView === 'home' && (
        <HeroSection onBookNow={handleBookNow} />
      )}

      {/* Navigation Bar (when not on home) */}
      {currentView !== 'home' && (
        <nav className="bg-white shadow-soft border-b border-eco-light sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold text-eco-green">EcoCollect</h1>
              <Button
                onClick={() => setCurrentView('home')}
                variant="outline"
                className="border-eco-green text-eco-green hover:bg-eco-light"
              >
                Back to Home
              </Button>
            </div>
          </div>
        </nav>
      )}

      {/* Booking Form Section */}
      {currentView === 'booking' && (
        <section id="booking-section" className="py-12 bg-gradient-soft min-h-screen">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-eco-green mb-6">
                Book Your Collection
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Fill out the form below to schedule your waste collection service
              </p>
            </div>
            <BookingForm onSubmit={handleBookingSubmit} />
          </div>
        </section>
      )}

      {/* How It Works Section */}
      {currentView === 'home' && <HowItWorks />}

      {/* Footer */}
      {currentView === 'home' && (
        <footer className="bg-eco-green text-white py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="col-span-1 md:col-span-2">
                <h3 className="text-2xl font-bold mb-4">EcoCollect</h3>
                <p className="text-white/80 mb-6 max-w-md">
                  Professional waste collection services committed to environmental sustainability 
                  and community health. Making waste management simple and eco-friendly.
                </p>
                <div className="flex space-x-4">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold">FB</span>
                  </div>
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold">TW</span>
                  </div>
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold">IG</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="text-lg font-semibold mb-4">Services</h4>
                <ul className="space-y-2 text-white/80">
                  <li>Residential Collection</li>
                  <li>Commercial Pickup</li>
                  <li>Electronic Waste</li>
                  <li>Recycling Services</li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-lg font-semibold mb-4">Contact</h4>
                <ul className="space-y-2 text-white/80">
                  <li>+1 (555) 123-4567</li>
                  <li>info@ecocollect.com</li>
                  <li>Available 24/7</li>
                  <li>Same-day service</li>
                </ul>
              </div>
            </div>
            
            <div className="border-t border-white/20 mt-12 pt-8 text-center text-white/60">
              <p>&copy; 2024 EcoCollect. All rights reserved. Making the world cleaner, one pickup at a time.</p>
            </div>
          </div>
        </footer>
      )}

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 w-12 h-12 rounded-full bg-gradient-eco hover:shadow-eco transition-all duration-300 z-50"
          size="icon"
        >
          <ArrowUp className="w-5 h-5" />
        </Button>
      )}
    </div>
  );
};

export default Index;