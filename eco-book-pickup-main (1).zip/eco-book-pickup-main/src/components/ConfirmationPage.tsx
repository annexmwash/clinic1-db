import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Edit, MapPin, Calendar, Clock, CreditCard, Trash2, User, Phone, Mail } from 'lucide-react';
import { format } from 'date-fns';
import { BookingData } from '@/components/BookingForm';

interface ConfirmationPageProps {
  bookingData: BookingData;
  onEdit: () => void;
  onConfirm: () => void;
}

const ConfirmationPage: React.FC<ConfirmationPageProps> = ({ bookingData, onEdit, onConfirm }) => {
  const calculateTotal = () => {
    const kg = parseFloat(bookingData.amount) || 0;
    return (kg * bookingData.ratePerKg).toFixed(2);
  };

  const generateBookingId = () => {
    return `WC${Date.now().toString().slice(-6)}`;
  };

  return (
    <div className="min-h-screen bg-gradient-soft py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-eco rounded-full flex items-center justify-center mx-auto mb-6 shadow-eco">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-eco-green mb-4">
            Booking Confirmation
          </h1>
          <p className="text-xl text-muted-foreground">
            Please review your booking details before final confirmation
          </p>
        </div>

        {/* Booking ID */}
        <Card className="mb-8 border-eco-light shadow-soft">
          <CardContent className="p-6 text-center">
            <h2 className="text-lg font-semibold text-eco-green mb-2">Booking Reference</h2>
            <div className="text-3xl font-bold text-eco-green">
              {generateBookingId()}
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Save this reference number for tracking your collection
            </p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Customer & Location Info */}
          <div className="space-y-6">
            <Card className="border-eco-light shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-eco-green">
                  <User className="w-5 h-5" />
                  Customer Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">{bookingData.fullName}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{bookingData.phone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>{bookingData.email}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-eco-light shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-eco-green">
                  <MapPin className="w-5 h-5" />
                  Pickup Location
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="font-medium">{bookingData.address}</p>
                <p className="text-muted-foreground">{bookingData.city}</p>
              </CardContent>
            </Card>
          </div>

          {/* Waste & Schedule Info */}
          <div className="space-y-6">
            <Card className="border-eco-light shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-eco-green">
                  <Trash2 className="w-5 h-5" />
                  Waste Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Type:</span>
                  <Badge variant="secondary" className="bg-eco-light text-eco-green">
                    {bookingData.wasteType}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Amount:</span>
                  <span className="font-medium">{bookingData.amount} kg</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Rate:</span>
                  <span>KSh {bookingData.ratePerKg}/kg</span>
                </div>
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between text-lg font-bold text-eco-green">
                    <span>Total Cost:</span>
                    <span>KSh {calculateTotal()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-eco-light shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-eco-green">
                  <Calendar className="w-5 h-5" />
                  Collection Schedule
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">
                    {bookingData.date ? format(bookingData.date, "EEEE, MMMM d, yyyy") : "No date selected"}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span>{bookingData.timeSlot}</span>
                </div>
                <div className="flex items-center gap-3">
                  <CreditCard className="w-4 h-4 text-muted-foreground" />
                  <span>{bookingData.paymentMethod}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Important Notice */}
        <Card className="mt-8 bg-eco-soft border-eco-light">
          <CardContent className="p-6">
            <h3 className="font-semibold text-eco-green mb-3">Important Notice:</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Please ensure someone is available at the pickup location during the scheduled time</li>
              <li>• Have your waste properly sorted and accessible for collection</li>
              <li>• You will receive an SMS confirmation once your booking is confirmed</li>
              <li>• For any changes or cancellations, contact us at least 2 hours before pickup</li>
            </ul>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
          <Button
            onClick={onEdit}
            variant="outline"
            size="lg"
            className="px-8 py-4 text-lg border-eco-green text-eco-green hover:bg-eco-light"
          >
            <Edit className="w-5 h-5 mr-2" />
            Edit Details
          </Button>
          <Button
            onClick={onConfirm}
            size="lg"
            className="px-8 py-4 text-lg bg-gradient-eco hover:shadow-eco transition-all duration-300"
          >
            <CheckCircle className="w-5 h-5 mr-2" />
            Confirm Booking
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationPage;