import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, Truck, Recycle } from 'lucide-react';

const steps = [
  {
    icon: Calendar,
    title: "Book Pickup",
    description: "Fill out our simple online form with your waste details and preferred collection time. Quick and easy scheduling in just a few clicks."
  },
  {
    icon: Truck,
    title: "Waste Collected",
    description: "Our professional team arrives at your location on time with proper equipment. Safe and efficient collection of your waste materials."
  },
  {
    icon: Recycle,
    title: "Safe Disposal & Recycling",
    description: "We ensure proper sorting, recycling, and eco-friendly disposal. Contributing to environmental sustainability and waste reduction."
  }
];

const HowItWorks = () => {
  return (
    <section className="py-20 bg-gradient-soft">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-eco-green mb-6">
            How It Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our simple 3-step process makes waste collection effortless and environmentally responsible
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="h-full border-eco-light hover:border-eco-green transition-colors duration-300 hover:shadow-eco">
                <CardContent className="p-8 text-center">
                  {/* Step Number */}
                  <div className="w-16 h-16 bg-gradient-eco rounded-full flex items-center justify-center mx-auto mb-6 shadow-eco">
                    <span className="text-2xl font-bold text-white">{index + 1}</span>
                  </div>

                  {/* Icon */}
                  <div className="w-20 h-20 bg-eco-light rounded-full flex items-center justify-center mx-auto mb-6">
                    <step.icon className="w-10 h-10 text-eco-green" />
                  </div>

                  {/* Content */}
                  <h3 className="text-2xl font-bold text-eco-green mb-4">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </CardContent>
              </Card>

              {/* Connector Arrow (desktop only) */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <div className="w-8 h-0.5 bg-eco-green"></div>
                  <div className="w-0 h-0 border-l-4 border-l-eco-green border-y-4 border-y-transparent ml-8 -mt-2"></div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-2xl p-8 shadow-soft max-w-4xl mx-auto border border-eco-light">
            <h3 className="text-2xl font-bold text-eco-green mb-4">
              Why Choose Our Service?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-eco-green rounded-full"></div>
                <span>Same-day pickup available</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-eco-green rounded-full"></div>
                <span>Competitive pricing</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-eco-green rounded-full"></div>
                <span>Eco-friendly disposal</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-eco-green rounded-full"></div>
                <span>Professional team</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;