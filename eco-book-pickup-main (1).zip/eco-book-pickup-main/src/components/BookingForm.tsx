import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { CalendarIcon, MapPin, Trash2, Clock, CreditCard, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useCities } from '@/hooks/useCities';
import { z } from 'zod';

const bookingSchema = z.object({
  fullName: z.string().trim().min(2, "Name must be at least 2 characters").max(100),
  phone: z.string().trim().min(10, "Phone number must be at least 10 digits").max(20),
  email: z.string().trim().email("Invalid email address").max(255),
  address: z.string().trim().min(10, "Address must be at least 10 characters").max(500),
  city: z.string().min(1, "Please select a city"),
  wasteType: z.string().min(1, "Please select waste type"),
  amount: z.string().refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Amount must be greater than 0"),
  date: z.date({ required_error: "Please select a date" }),
  timeSlot: z.string().min(1, "Please select a time slot"),
  paymentMethod: z.string().min(1, "Please select a payment method")
});

export interface BookingData {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  cityId: string;
  ratePerKg: number;
  wasteType: string;
  amount: string;
  date: Date | undefined;
  timeSlot: string;
  paymentMethod: string;
}

interface BookingFormProps {
  onSubmit: (data: BookingData) => void;
}

const WASTE_TYPES = [
  'Plastic',
  'Organic',
  'Electronic',
  'Metal',
  'Mixed',
  'Other'
];

const TIME_SLOTS = [
  'Morning (8:00 AM - 12:00 PM)',
  'Afternoon (12:00 PM - 4:00 PM)',
  'Evening (4:00 PM - 8:00 PM)'
];

const PAYMENT_OPTIONS = [
  'Cash on Collection',
  'Mobile Money',
  'Card Payment'
];

const BookingForm: React.FC<BookingFormProps> = ({ onSubmit }) => {
  const { data: cities, isLoading: citiesLoading } = useCities();
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const [formData, setFormData] = useState<BookingData>({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    cityId: '',
    ratePerKg: 2.5,
    wasteType: '',
    amount: '',
    date: undefined,
    timeSlot: '',
    paymentMethod: ''
  });

  const handleInputChange = (field: keyof BookingData, value: string | Date | undefined) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleCityChange = (cityId: string) => {
    const selectedCity = cities?.find(c => c.id === cityId);
    if (selectedCity) {
      setFormData(prev => ({
        ...prev,
        cityId: selectedCity.id,
        city: selectedCity.name,
        ratePerKg: selectedCity.rate_per_kg
      }));
      if (errors.city) {
        setErrors(prev => {
          const newErrors = { ...prev };
          delete newErrors.city;
          return newErrors;
        });
      }
    }
  };

  const calculateTotal = () => {
    const kg = parseFloat(formData.amount) || 0;
    return (kg * formData.ratePerKg).toFixed(2);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      bookingSchema.parse(formData);
      setErrors({});
      onSubmit(formData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach(err => {
          if (err.path[0]) {
            newErrors[err.path[0].toString()] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Customer Information */}
      <Card className="border-eco-light shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-eco-green">
            <div className="w-8 h-8 rounded-full bg-eco-light flex items-center justify-center">
              <span className="text-eco-green font-bold">1</span>
            </div>
            Customer Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="fullName">Full Name *</Label>
            <Input
              id="fullName"
              value={formData.fullName}
              onChange={(e) => handleInputChange('fullName', e.target.value)}
              placeholder="Enter your full name"
              required
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="+1 (555) 123-4567"
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="your.email@example.com"
                required
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Location Details */}
      <Card className="border-eco-light shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-eco-green">
            <div className="w-8 h-8 rounded-full bg-eco-light flex items-center justify-center">
              <MapPin className="w-4 h-4 text-eco-green" />
            </div>
            Location Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="address">Pickup Address *</Label>
            <Textarea
              id="address"
              value={formData.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              placeholder="Enter complete pickup address"
              required
            />
          </div>
          <div>
            <Label htmlFor="city">City/Town *</Label>
            <Select value={formData.cityId} onValueChange={handleCityChange} disabled={citiesLoading}>
              <SelectTrigger className={errors.city ? 'border-destructive' : ''}>
                <SelectValue placeholder={citiesLoading ? "Loading cities..." : "Select your city"} />
              </SelectTrigger>
              <SelectContent>
                {cities?.map((city) => (
                  <SelectItem key={city.id} value={city.id}>
                    {city.name} (KSh {city.rate_per_kg}/kg)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.city && <p className="text-sm text-destructive mt-1">{errors.city}</p>}
          </div>
        </CardContent>
      </Card>

      {/* Waste Information */}
      <Card className="border-eco-light shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-eco-green">
            <div className="w-8 h-8 rounded-full bg-eco-light flex items-center justify-center">
              <Trash2 className="w-4 h-4 text-eco-green" />
            </div>
            Waste Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="wasteType">Type of Waste *</Label>
            <Select value={formData.wasteType} onValueChange={(value) => handleInputChange('wasteType', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select waste type" />
              </SelectTrigger>
              <SelectContent>
                {WASTE_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="amount">Amount (kg) *</Label>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.1"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                placeholder="0.0"
                required
              />
            </div>
            <div>
              <Label>Total Cost</Label>
              <div className="p-3 bg-eco-soft rounded-lg border border-eco-light">
                <span className="text-lg font-semibold text-eco-green">
                  KSh {calculateTotal()}
                </span>
                <span className="text-sm text-muted-foreground ml-2">
                  (KSh {formData.ratePerKg}/kg)
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Collection Schedule */}
      <Card className="border-eco-light shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-eco-green">
            <div className="w-8 h-8 rounded-full bg-eco-light flex items-center justify-center">
              <Clock className="w-4 h-4 text-eco-green" />
            </div>
            Collection Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Preferred Date of Collection *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formData.date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.date ? format(formData.date, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formData.date}
                  onSelect={(date) => handleInputChange('date', date)}
                  disabled={(date) => date < new Date()}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <Label htmlFor="timeSlot">Preferred Time Slot *</Label>
            <Select value={formData.timeSlot} onValueChange={(value) => handleInputChange('timeSlot', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select time slot" />
              </SelectTrigger>
              <SelectContent>
                {TIME_SLOTS.map((slot) => (
                  <SelectItem key={slot} value={slot}>{slot}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Payment Options */}
      <Card className="border-eco-light shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-eco-green">
            <div className="w-8 h-8 rounded-full bg-eco-light flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-eco-green" />
            </div>
            Payment Options
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label htmlFor="paymentMethod">Payment Method *</Label>
            <Select value={formData.paymentMethod} onValueChange={(value) => handleInputChange('paymentMethod', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_OPTIONS.map((option) => (
                  <SelectItem key={option} value={option}>{option}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <Button 
        type="submit" 
        className="w-full bg-gradient-eco hover:shadow-eco transition-all duration-300 py-6 text-lg font-semibold"
      >
        Book Collection Service
      </Button>
    </form>
  );
};

export default BookingForm;